# TAJ Shopping Centre — Phase 1

This is a responsive, static frontend prototype for the TAJ Shopping Centre marketplace.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser, or upload the folder to a static hosting service.
3. Try the category filters, product search, and Add to cart buttons.

## Current prototype features
- Responsive desktop and mobile storefront
- TAJ brand header and navigation
- Search across demo products
- Category filtering
- Product cards and naira prices
- Demo cart counter and cart total toast

## Important limitations
This is a frontend prototype only. It does not yet have a backend, real customer/vendor accounts, database, live inventory, payment processing, order management, or delivery integration. Product names, prices, ratings and images are sample content. Do not accept real customer payments through this prototype.

## Next development step
Set up the Next.js project and Supabase backend, then convert this approved interface into reusable application components.
